""" FAVORITE SONG
    The following code creates an object song with some attributes which describe the song"""
#Set up the attributes for the Song
title = "Back in the Day & So Good"
album = "Live from the Inside"
artist = "Brian Culbertson"
year = 2009
genre = "Jazz"
lyrics = True
platforms = ["Spotify", "iCloud", "Youtube Music", "Deezer", "Play Music"]
author = "Brian Culbertson"
prizes = 4
track = 10

#Display the content of attributes
print("Title:     " + title)
print("Album:     " + album)
print("Artist:    " + artist)
print("Year:      " + str(year))
print("Genre:     " + genre)
print("Lyrics:    " + str(lyrics))
print("Platforms: " + str(platforms))
print("Author:    " + author)
print("Prizes:    " + str(prizes))
print("Track:     " + str(track))
